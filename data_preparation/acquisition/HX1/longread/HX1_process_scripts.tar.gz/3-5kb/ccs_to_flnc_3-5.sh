#!/bin/bash

echo '1 of 12'
bash baxh5s_to_ccs.sh SRR2918232

echo '2 of 12'
bash baxh5s_to_ccs.sh SRR2918233

echo '3 of 12'
bash baxh5s_to_ccs.sh SRR2918234

echo '4 of 12'
bash baxh5s_to_ccs.sh SRR2918235

echo '5 of 12'
bash baxh5s_to_ccs.sh SRR2918236

echo '6 of 12'
bash baxh5s_to_ccs.sh SRR2918237

echo '7 of 12'
bash baxh5s_to_ccs.sh SRR2918238

echo '8 of 12'
bash baxh5s_to_ccs.sh SRR2918239

echo '9 of 12'
bash baxh5s_to_ccs.sh SRR2918240

echo '10 of 12'
bash baxh5s_to_ccs.sh SRR2918241

echo '11 of 12'
bash baxh5s_to_ccs.sh SRR2918242

echo '12 of 12'
bash baxh5s_to_ccs.sh SRR2918243
