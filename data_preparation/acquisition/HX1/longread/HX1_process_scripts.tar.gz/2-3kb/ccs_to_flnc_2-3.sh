#!/bin/bash

#ACCNUM=$1
BARCODES=/home/davidju/benchmarking_ri_pacbio/primer_barcodes.fa

echo '1 of 12'
bash baxh5s_to_ccs.sh SRR2918203

echo 'processing 2 of 12'
bash baxh5s_to_ccs.sh SRR2918204

echo '3 of 12'
bash baxh5s_to_ccs.sh SRR2918205

echo '4 of 12'
bash baxh5s_to_ccs.sh SRR2918206

echo '5 of 12'
bash baxh5s_to_ccs.sh SRR2918207

echo '6 of 12'
bash baxh5s_to_ccs.sh SRR2918208

echo '7 of 12'
bash baxh5s_to_ccs.sh SRR2918209

echo '8 of 12'
bash baxh5s_to_ccs.sh SRR2918210

echo '9 of 12'
bash baxh5s_to_ccs.sh SRR2918211

echo '10 of 12'
bash baxh5s_to_ccs.sh SRR2918212

echo '11 of 12'
bash baxh5s_to_ccs.sh SRR2918213

echo '12 of 12'
bash baxh5s_to_ccs.sh SRR2918214
