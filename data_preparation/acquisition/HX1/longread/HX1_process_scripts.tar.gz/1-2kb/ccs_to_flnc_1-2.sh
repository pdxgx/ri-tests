#!/bin/bash

#ACCNUM=$1
BARCODES=/home/davidju/benchmarking_ri_pacbio/primer_barcodes.fa

echo '2 of 10'
bash baxh5s_to_ccs.sh SRR2918174

echo 'process 3 of 10'
bash baxh5s_to_ccs.sh SRR2918175

echo '4 of 10'
bash baxh5s_to_ccs.sh SRR2918176  

echo '5 of 10'
bash baxh5s_to_ccs.sh SRR2918177

echo '6 of 10'
bash baxh5s_to_ccs.sh SRR2918178

echo '7 of 10'
bash baxh5s_to_ccs.sh SRR2918179

echo '8 of 10'
bash baxh5s_to_ccs.sh SRR2918180

echo '9 of 10'
bash baxh5s_to_ccs.sh SRR2918181

echo '10 of 10'
bash baxh5s_to_ccs.sh SRR2918182
