#!/bin/bash

ACCNUM=$1
BARCODES=/home/davidju/benchmarking_ri_pacbio/primer_barcodes.fa

#echo 'bax2bam'
#time bax2bam -o "${ACCNUM}" *.bax.h5

echo 'starting conda env'
#conda activate isoseq-env
#source activate isoseq-env
source activate /home/davidju/anaconda3/envs/isoseq-env

#echo 'run ccs version 3.4'
#time ccs --minPasses 1 --minPredictedAccuracy 0.90 "${ACCNUM}".subreads.bam "${ACCNUM}".ccs.bam

echo 'run lima'
time lima "${ACCNUM}".ccs.bam "$BARCODES" "${ACCNUM}".demux.bam  --isoseq 

echo 'rename isoseq demuxed bams'
mv "${ACCNUM}".demux.oligo_5p--primer_3p.bam "${ACCNUM}".demux.ccs.bam
mv "${ACCNUM}".demux.oligo_5p--primer_3p.bam.pbi "${ACCNUM}".demux.ccs.bam.pbi
mv "${ACCNUM}".demux.oligo_5p--primer_3p.consensusreadset.xml "${ACCNUM}".demux.ccs.consensusreadset.xml

#samtools 
echo 'run isoseq refine to remove polyAs'
time isoseq3 refine --require-polya "${ACCNUM}".demux.ccs.bam "${BARCODES}" "${ACCNUM}".flnc.bam

echo 'deactivating venv'
#conda deactivate
source deactivate
