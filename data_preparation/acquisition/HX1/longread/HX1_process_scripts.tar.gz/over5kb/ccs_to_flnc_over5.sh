#!/bin/bash

#ACCNUM=$1

echo '1 of 12'
bash baxh5s_to_ccs.sh SRR2918245

echo '2 of 12'
bash baxh5s_to_ccs.sh SRR2918246

echo '3 of 12'
bash baxh5s_to_ccs.sh SRR2918247

echo '4 of 12'
bash baxh5s_to_ccs.sh SRR2918248

echo '5 of 12'
bash baxh5s_to_ccs.sh SRR2918249

echo '6 of 12'
bash baxh5s_to_ccs.sh SRR2918250

echo '7 of 12'
bash baxh5s_to_ccs.sh SRR2918251

echo '8 of 12'
bash baxh5s_to_ccs.sh SRR2918252

echo '9 of 12'
bash baxh5s_to_ccs.sh SRR2918253

echo '10 of 12'
bash baxh5s_to_ccs.sh SRR2918254

echo '11 of 12'
bash baxh5s_to_ccs.sh SRR2918255

echo '12 of 12'
bash baxh5s_to_ccs.sh SRR2918256
